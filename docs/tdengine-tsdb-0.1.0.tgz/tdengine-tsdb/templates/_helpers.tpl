{{/* ---------------------------------------------------------------- names */}}

{{- define "tdengine-tsdb.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Full name. Capped at 40 characters: StatefulSet names over 52 characters break
the controller-revision-hash label, and the name is also embedded in every
dnode FQDN, which TDengine limits (see "tdengine-tsdb.validate").
*/}}
{{- define "tdengine-tsdb.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 40 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 40 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 40 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "tdengine-tsdb.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "tdengine-tsdb.headlessName" -}}
{{- printf "%s-headless" (include "tdengine-tsdb.fullname" .) }}
{{- end }}

{{- define "tdengine-tsdb.explorerName" -}}
{{- printf "%s-explorer" (include "tdengine-tsdb.fullname" .) }}
{{- end }}

{{/* --------------------------------------------------------------- labels */}}

{{- define "tdengine-tsdb.selectorLabels" -}}
app.kubernetes.io/name: {{ include "tdengine-tsdb.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "tdengine-tsdb.labels" -}}
helm.sh/chart: {{ include "tdengine-tsdb.chart" . }}
{{ include "tdengine-tsdb.selectorLabels" . }}
app.kubernetes.io/version: {{ include "tdengine-tsdb.imageTag" . | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/* Component selector: call with (dict "ctx" $ "component" "server") */}}
{{- define "tdengine-tsdb.componentSelectorLabels" -}}
{{ include "tdengine-tsdb.selectorLabels" .ctx }}
app.kubernetes.io/component: {{ .component }}
{{- end }}

{{- define "tdengine-tsdb.componentLabels" -}}
{{ include "tdengine-tsdb.labels" .ctx }}
app.kubernetes.io/component: {{ .component }}
{{- end }}

{{/* ---------------------------------------------------------------- image */}}

{{- define "tdengine-tsdb.imageTag" -}}
{{- default .Chart.AppVersion .Values.image.tag }}
{{- end }}

{{- define "tdengine-tsdb.image" -}}
{{- printf "%s:%s" .Values.image.repository (include "tdengine-tsdb.imageTag" .) }}
{{- end }}

{{/* --------------------------------------------------------------- secret */}}

{{- define "tdengine-tsdb.secretName" -}}
{{- if .Values.auth.existingSecret }}
{{- .Values.auth.existingSecret }}
{{- else }}
{{- printf "%s-auth" (include "tdengine-tsdb.fullname" .) }}
{{- end }}
{{- end }}

{{- define "tdengine-tsdb.secretKey" -}}
{{- if .Values.auth.existingSecret }}
{{- .Values.auth.existingSecretKey }}
{{- else }}
{{- "root-password" }}
{{- end }}
{{- end }}

{{/* -------------------------------------------------------------- storage */}}

{{/* Storage class for dnode volumes; empty string means "omit the field". */}}
{{- define "tdengine-tsdb.storageClassName" -}}
{{- if .Values.storageClass.create }}
{{- .Values.storageClass.name }}
{{- else }}
{{- .Values.persistence.storageClassName }}
{{- end }}
{{- end }}

{{/* ---------------------------------------------------------------- dns */}}

{{- define "tdengine-tsdb.clientHost" -}}
{{- printf "%s.%s.svc.%s" (include "tdengine-tsdb.fullname" .) .Release.Namespace .Values.clusterDomain }}
{{- end }}

{{/* FQDN of dnode <index>. The same format is built at runtime from POD_NAME. */}}
{{- define "tdengine-tsdb.dnodeFqdn" -}}
{{- printf "%s-%d.%s.%s.svc.%s" (include "tdengine-tsdb.fullname" .ctx) (int .index) (include "tdengine-tsdb.headlessName" .ctx) .ctx.Release.Namespace .ctx.Values.clusterDomain }}
{{- end }}
