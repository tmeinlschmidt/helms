#!/usr/bin/env bash
#
# Bootstrap a TDengine TSDB cluster once its dnodes are running:
#
#   1. wait until the REST API answers
#   2. wait until every dnode has joined and is ready
#   3. when there are >= 3 dnodes, add mnodes until there are 3 (HA)
#   4. create the configured databases (IF NOT EXISTS — never alters existing)
#
# Runs as a Helm post-install/post-upgrade hook. Safe to re-run: every step
# checks current state first.
#
# The image has curl but no jq or python (verified), so JSON is parsed with
# bash and sed, and every query is shaped to return something trivial to parse.

set -euo pipefail

: "${API_HOST:?API_HOST is required}"
: "${REPLICAS:?REPLICAS is required}"
: "${TAOS_PW:?TAOS_PW is required}"
TIMEOUT="${TIMEOUT:-1200}"
CREATE_MNODES="${CREATE_MNODES:-true}"
# Space-separated "fqdn:port" of every dnode the StatefulSet should have.
EXPECTED_ENDPOINTS="${EXPECTED_ENDPOINTS:-}"
REGISTER_GRACE_SECONDS="${REGISTER_GRACE_SECONDS:-60}"
# Resolver used to tell whether a dnode's pod exists (headless Service DNS).
RESOLVE_CMD="${RESOLVE_CMD:-getent hosts}"
DB_FILE="${DB_FILE:-/bootstrap/databases.txt}"
API="${API_URL:-http://${API_HOST}:6041/rest/sql}"
POLL_SECONDS="${POLL_SECONDS:-5}"

START_TS=$(date +%s)
DEADLINE=$(( START_TS + TIMEOUT ))
# Errors are written to a file, not a variable: sql() usually runs inside $(...),
# a subshell, where assignments to globals are lost.
ERR_FILE="$(mktemp)"
trap 'rm -f "$ERR_FILE"' EXIT

log() { printf '%s %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*"; }
die() { log "ERROR: $*"; exit 1; }
last_error() { cat "$ERR_FILE" 2>/dev/null || true; }
set_error() { printf '%s' "$*" > "$ERR_FILE"; }

# sql_once <statement>
# Runs one statement through taosAdapter's REST API and prints the JSON body.
# taosAdapter returns HTTP 200 even for SQL errors (verified, docs), so success
# is judged by "code":0 in the body — an empty or unexpected body is a failure,
# never a result.
# Returns 2 on transport failure, 1 on SQL error.
sql_once() {
  local body
  # Credentials go through stdin (-K -) so they never appear in the process list.
  if ! body=$(curl -sS --max-time 30 -K - --data-binary "$1" "$API" 2>&1 \
      <<< "user = \"root:${TAOS_PW}\""); then
    set_error "transport error: ${body}"
    return 2
  fi
  if [[ ! "$body" =~ \"code\"[[:space:]]*:[[:space:]]*0[[:space:]]*, ]]; then
    set_error "SQL error: ${body:-<empty response>}"
    return 1
  fi
  printf '%s' "$body"
}

# sql <statement>
# sql_once, retrying TRANSPORT errors a bounded number of times. The API sits
# behind a load-balanced Service: during a rolling restart, or while one dnode's
# adapter is still starting, an individual request can be refused even though
# the cluster is fine. Seen on a real cluster with chart 0.1.0, where a single
# refused connection right after "dnodes ready" killed the job.
# Bounded (not until the deadline) so that a real outage still surfaces in the
# caller's "waiting for ..." log instead of retrying silently. SQL errors are
# returned immediately — retrying a rejected statement does not help.
SQL_TRANSPORT_RETRIES="${SQL_TRANSPORT_RETRIES:-12}"
sql() {
  local rc attempt=1
  while true; do
    sql_once "$1" && return 0
    rc=$?
    if (( rc != 2 )) || (( attempt >= SQL_TRANSPORT_RETRIES )) || (( $(date +%s) >= DEADLINE )); then
      return "$rc"
    fi
    attempt=$(( attempt + 1 ))
    sleep "$POLL_SECONDS"
  done
}

# scalar <statement> — prints the single integer of a "data":[[N]] result.
scalar() {
  local body value
  body=$(sql "$1") || return $?
  value=$(printf '%s' "$body" \
    | sed -nE 's/.*"data"[[:space:]]*:[[:space:]]*\[[[:space:]]*\[[[:space:]]*([0-9]+)[[:space:]]*\][[:space:]]*\].*/\1/p')
  if [[ -z "$value" ]]; then
    set_error "unexpected response to '$1': ${body}"
    return 1
  fi
  printf '%s' "$value"
}

# wait_for <description> <command> [args...] — retry until the command succeeds.
wait_for() {
  local what=$1 attempt=0
  shift
  while true; do
    if "$@"; then
      return 0
    fi
    if (( $(date +%s) >= DEADLINE )); then
      die "timed out waiting for ${what}. Last state: $(last_error)"
    fi
    if (( attempt % 6 == 0 )); then
      log "waiting for ${what}: $(last_error)"
    fi
    attempt=$(( attempt + 1 ))
    sleep "$POLL_SECONDS"
  done
}

# ---------------------------------------------------------------- conditions

api_up() {
  # verified (docs): `show databases` over REST returns code 0 with data rows.
  # Single attempt: wait_for already retries, and logs while it does.
  sql_once "show databases" > /dev/null
}

# register_missing_dnodes
# The image entrypoint joins each secondary with CREATE DNODE. On a real cluster
# (TDengine 3.4.2.8, two secondaries joining within the same second) that
# statement returned success with EMPTY output while registering nothing: the
# dnode's taosd then waited forever, logging "Dnode does not exist" every
# second, and the install timed out.
#
# So after a grace period (letting the entrypoint do its normal job first),
# register any expected dnode that is still missing — but only if its DNS name
# resolves, i.e. its pod actually exists. Registering a dnode for a Pending pod
# would leave a permanently offline cluster member. Safe against races: if the
# entrypoint registers the same dnode, one side gets "already exists".
register_missing_dnodes() {
  local registered ep host resolver
  [[ -n "$EXPECTED_ENDPOINTS" ]] || return 0
  (( $(date +%s) - START_TS >= REGISTER_GRACE_SECONDS )) || return 0
  read -ra resolver <<< "$RESOLVE_CMD"
  registered=$(sql "select endpoint from information_schema.ins_dnodes") || return 1
  for ep in $EXPECTED_ENDPOINTS; do
    [[ "$registered" == *"\"${ep}\""* ]] && continue
    host=${ep%:*}
    if ! "${resolver[@]}" "$host" > /dev/null 2>&1; then
      continue  # pod does not exist (yet)
    fi
    log "dnode ${ep} has a running pod but is not registered; registering it"
    if ! sql "create dnode '${ep}'" > /dev/null; then
      if grep -qi 'already exist' "$ERR_FILE"; then
        log "dnode ${ep} already exists"
      else
        log "WARNING: create dnode ${ep}: $(last_error)"
      fi
    fi
  done
}

dnodes_ready() {
  local n
  n=$(scalar "select count(*) from information_schema.ins_dnodes where status = 'ready'") || return 1
  if (( n >= REPLICAS )); then
    log "dnodes ready: ${n}/${REPLICAS}"
    return 0
  fi
  register_missing_dnodes || true
  set_error "${n} of ${REPLICAS} dnodes ready"
  return 1
}

mnodes_ready() {
  local want=$1 n
  n=$(scalar "select count(*) from information_schema.ins_mnodes where status = 'ready'") || return 1
  if (( n >= want )); then
    return 0
  fi
  set_error "${n} of ${want} mnodes ready"
  return 1
}

# ------------------------------------------------------------------- steps

ensure_mnodes() {
  local count dnodes mnodes candidate id ep
  count=$(scalar "select count(*) from information_schema.ins_mnodes") \
    || die "counting mnodes: $(last_error)"
  log "mnodes present: ${count}"

  # verified (docs): a cluster has at most 3 mnodes, one per dnode, and
  # information_schema.ins_mnodes has no dnode_id column — so dnodes are matched
  # to mnodes by endpoint.
  while (( count < 3 )); do
    dnodes=$(sql "select id, endpoint from information_schema.ins_dnodes where status = 'ready' order by id") \
      || die "listing dnodes: $(last_error)"
    mnodes=$(sql "select endpoint from information_schema.ins_mnodes") \
      || die "listing mnodes: $(last_error)"

    candidate=""
    while read -r id ep; do
      [[ -n "$id" ]] || continue
      if [[ "$mnodes" != *"\"${ep}\""* ]]; then
        candidate=$id
        break
      fi
    done < <(printf '%s' "$dnodes" \
      | grep -oE '\[[[:space:]]*[0-9]+[[:space:]]*,[[:space:]]*"[^"]+"[[:space:]]*\]' \
      | sed -E 's/\[[[:space:]]*([0-9]+)[[:space:]]*,[[:space:]]*"([^"]+)"[[:space:]]*\]/\1 \2/')

    if [[ -z "$candidate" ]]; then
      die "need 3 mnodes but every ready dnode already hosts one (have ${count})"
    fi

    log "creating mnode on dnode ${candidate}"
    if ! sql "create mnode on dnode ${candidate}" > /dev/null; then
      if grep -qi 'already exist' "$ERR_FILE"; then
        log "mnode on dnode ${candidate} already exists"
      else
        die "create mnode on dnode ${candidate}: $(last_error)"
      fi
    fi

    # One at a time: let each new mnode reach ready before adding the next.
    wait_for "mnode on dnode ${candidate} to become ready" mnodes_ready $(( count + 1 ))
    count=$(scalar "select count(*) from information_schema.ins_mnodes") \
      || die "counting mnodes: $(last_error)"
    log "mnodes present: ${count}"
  done
}

create_databases() {
  local name replica keep precision options stmt
  if [[ ! -s "$DB_FILE" ]]; then
    log "no databases configured"
    return 0
  fi
  # One database per line: name|replica|keep|precision|options
  # Values are validated by the chart before they reach this file.
  while IFS='|' read -r name replica keep precision options; do
    [[ -n "$name" ]] || continue
    stmt="create database if not exists ${name} replica ${replica:-1}"
    [[ -z "$keep" ]] || stmt+=" keep ${keep}"
    [[ -z "$precision" ]] || stmt+=" precision '${precision}'"
    [[ -z "$options" ]] || stmt+=" ${options}"
    log "${stmt}"
    sql "$stmt" > /dev/null || die "creating database ${name}: $(last_error)"
  done < "$DB_FILE"
}

# -------------------------------------------------------------------- main

log "bootstrap: expecting ${REPLICAS} dnode(s), REST API ${API}"
wait_for "REST API" api_up
wait_for "all ${REPLICAS} dnodes to be ready" dnodes_ready

if [[ "$CREATE_MNODES" == "true" ]] && (( REPLICAS >= 3 )); then
  ensure_mnodes
else
  log "skipping mnode creation (replicas=${REPLICAS}, createMnodes=${CREATE_MNODES})"
fi

create_databases
log "bootstrap complete"
