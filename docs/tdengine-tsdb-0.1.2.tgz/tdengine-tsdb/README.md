# tdengine-tsdb

Helm chart for a **TDengine TSDB-OSS** cluster on Kubernetes: a StatefulSet of
dnodes that join automatically, a bootstrap job that makes the management layer
highly available, a Longhorn StorageClass, and Ingress for the Explorer UI and
the REST / InfluxDB API.

Written for k3s + Rancher + Longhorn, but nothing in it is k3s-specific.

## Quick start

```sh
helm upgrade --install tsdb ./tdengine-tsdb \
  -n tdengine --create-namespace \
  --set ingress.explorer.host=tsdb.example.org \
  --timeout 20m
```

Use `--timeout 20m`. The bootstrap hook waits for every dnode to join and every
mnode to become ready, and Helm's default 5 minutes can run out on a first
install while images pull.

Then:

```sh
helm test tsdb -n tdengine     # dnodes, mnodes, and a real write/read round-trip
```

See [`examples/values-home.yaml`](examples/values-home.yaml) for a full HA setup
with TLS.

## What it deploys

| Resource | Purpose |
|---|---|
| StatefulSet | `replicaCount` dnodes running `taosd`, `taosadapter` and `taoskeeper` |
| Service (headless) | Stable per-dnode DNS names, used as each dnode's TDengine FQDN |
| Service | Client endpoint: 6030 native, 6041 REST/WebSocket/InfluxDB, 6043 keeper |
| Deployment | Explorer web UI, one replica |
| Job (hook) | Waits for the cluster, creates mnodes and databases |
| StorageClass | Dedicated Longhorn class (optional) |
| Secret | Root password, generated once and kept |
| PodDisruptionBudget | At most one dnode down during drains (3+ dnodes) |
| Ingress | Explorer UI and/or REST API, each on its own host |

## High availability

The official docs require all three of:

1. **3 or more dnodes** — `replicaCount: 3`
2. **3 mnodes** — the image only ever creates one; the bootstrap job adds two more
3. **Databases created with `REPLICA 3`** — TDengine defaults to `REPLICA 1`

The chart handles 1 and 2. **Number 3 is yours**: every database needs
`REPLICA 3`, either through `bootstrap.databases` or in your own
`CREATE DATABASE` statements. A `REPLICA 1` database lives on one dnode and is
unavailable when that dnode is down, whatever the chart does.

`replicaCount: 2` is rejected. Two-replica databases are TSDB-Enterprise only,
so two dnodes add a failure point without adding tolerance.

## Storage and replication layers

Longhorn replicates the block device. TDengine replicates `REPLICA 3` databases
through Raft. Stacking both multiplies every write.

| Setting | Survives node loss for | Write copies (REPLICA 3 db) |
|---|---|---|
| **Default** — Longhorn `2`, `best-effort` | every database, including REPLICA 1 | 6 |
| Longhorn `1`, `strict-local` | REPLICA 3 databases only | 3 |

The default is the safe one, because taosKeeper's own `log` database and any
database created without an explicit replica count are `REPLICA 1`. Switch to
the second row only once every database you care about is `REPLICA 3`.

`strict-local` requires exactly one Longhorn replica; the chart refuses
anything else, because Longhorn would reject the volume.

The StorageClass uses `reclaimPolicy: Retain`, so `helm uninstall` leaves the
data volumes behind. Delete the PVCs and PVs yourself when you mean it.

## Passwords

The root password is set by the image entrypoint on **first boot only**.

- Leave `auth.rootPassword` empty to generate one. It is kept across upgrades
  and survives `helm uninstall` (`helm.sh/resource-policy: keep`), because the
  data on the retained volumes only accepts that password.
- A password you supply must be 8–255 characters with at least 3 of:
  uppercase, lowercase, digits, special. The chart checks this, because a weak
  password makes the first boot fail and the first dnode crash-loop.
- **Changing the value later does not change the password.** It breaks the
  health checks, which authenticate with it. Change it with
  `ALTER USER root PASS '...'` first, then update the Secret.

## Scaling

**Up**: raise `replicaCount` and upgrade. New dnodes join on their own, and the
bootstrap job adds mnodes if you cross from 1 to 3.

**Down** is never automatic. A dnode that just disappears is still a cluster
member, which the cluster keeps waiting for. The chart refuses to lower
`replicaCount` on an existing release unless you pass `allowScaleDown=true`.
First, while the dnodes being removed are still online:

```sql
SHOW DNODES;
DROP DNODE <id>;   -- for each dnode being removed (highest pod ordinals)
```

TDengine drops an online dnode cleanly. An offline one needs `FORCE`, and an
offline one holding single-replica data needs `UNSAFE`, which loses that data.

## Access from outside the cluster

Use **REST or WebSocket on port 6041**, through `ingress.api`:

```
https://<api-host>/rest/sql
https://<api-host>/influxdb/v1/write?db=<database>
```

Native connections (6030) do not work reliably from outside. The cluster hands
native clients each dnode's FQDN, which only resolves inside the cluster.

`server.adapter.smlAutoCreateDB` defaults to `false`, as in the image, so
InfluxDB-protocol writes to a database that does not exist are rejected. Create
the database first or turn this on.

## Design notes

Where the chart deliberately differs from TDengine's example YAML:

- **Liveness uses `taos-check startup`, not `service`.** `service` asks whether
  the *cluster* is alive; using it for liveness would make Kubernetes restart
  the surviving dnodes when quorum is lost, which only makes things worse.
  Readiness still uses `service`.
- **Proper headless Service with `publishNotReadyAddresses`.** Dnodes have to
  reach each other before any is Ready: during first join, and after a full
  restart while Raft re-forms.
- **`podManagementPolicy: Parallel`.** `OrderedReady` can deadlock after a full
  restart, since no dnode is Ready until several are up. The entrypoint already
  sequences first boot.
- **Hard anti-affinity by default.** Two dnodes on one node means one node
  failure costs quorum. Pending pods are visible; a silently non-HA cluster is
  not.
- **Explorer runs separately.** The docs call it not cluster-ready, so it is
  disabled inside the dnode pods.
- **Databases are created by the hook, not the image's init scripts.** Init
  scripts run on dnode 1 before the others join, so `REPLICA 3` would fail
  there and crash-loop it.
- **Memory limit on by default.** An OOM-killed pod is recoverable; a node
  brought down by an unbounded database is not.

## What was verified, and how

Checked directly against `tdengine/tsdb:3.4.2.8` (pulled from Docker Hub), not
taken from older charts or memory:

- **Entrypoint** (`/usr/bin/entrypoint.sh`, read in full): role detection from
  `TAOS_FQDN` vs `TAOS_FIRST_EP`, automatic `CREATE DNODE`, first-boot-only
  password change, `TAOS_ROOT_PASSWORD_FILE`, `TAOS_DISABLE_*` switches, and the
  fact that it creates exactly one mnode
- **Shipped binaries**: `taosd`, `taosadapter`, `taoskeeper`, `taos-explorer`,
  CLI tools. No `taosx`, which is Enterprise
- **Env var names** read out of the binaries: `TAOS_ADAPTER_SML_AUTO_CREATE_DB`,
  `TAOS_ADAPTER_MONITOR_INCGROUP`, `EXPLORER_CLUSTER`. The docs' prose form
  `TAOS_MONITOR_*` does not exist in the binary. Note: the docs recommend
  `monitor.incgroup = true` in containers, but on cgroup v2 hosts it makes
  taosadapter crash at startup — see the changelog — so the chart leaves it at
  the image default
- **Default configs** in `/etc/taos/`, including the Explorer TOML keys
- **Docs** (docs.tdengine.com, 2026-09-13): HA requirements, `CREATE MNODE`,
  `DROP DNODE` semantics, `CREATE DATABASE` options, REPLICA 2 being Enterprise,
  password policy, `information_schema.ins_dnodes` / `ins_mnodes` columns, REST
  response format
- **Longhorn 1.12.1 docs**: StorageClass parameter names, strict-local requiring
  one replica

Tested:

- `helm lint`
- Strict kubeconform schema validation on Kubernetes 1.30 and 1.33, for
  defaults, single-node, and an every-option configuration
- 14 invalid configurations, each confirmed rejected
- `NOTES.txt` rendered via client dry-run
- `files/bootstrap.sh` run against a mock taosAdapter in 14 scenarios: fresh
  3-node cluster, already converged (idempotent re-run), single node, API down
  at start, API persistently down, API intermittently refusing connections
  mid-run, wrong password, dnodes never ready (timeout), `CREATE MNODE`
  failure, mnode creation disabled, and a dnode that silently never joins
  (registered; feature off; pod missing; still within grace period)
- **On a real cluster** (6 × Raspberry Pi 5, k3s v1.34.11, arm64, cgroup v2,
  Longhorn): 3 dnodes ready; the 0.1.1 bootstrap script, run by hand inside a
  dnode pod against the real REST API, created mnodes 1 → 3 (1 leader, 2
  followers); a `REPLICA 3` database created / written / read back / dropped;
  the Explorer pod reaching the REST API (HTTP 200). Not yet exercised there:
  the bootstrap as a Helm hook, and `helm test` itself

Worth knowing from that run: dnode IDs follow **join order, not pod ordinal**
(pod 2 became dnode 2, pod 1 became dnode 3). The bootstrap job therefore
matches mnodes to dnodes by endpoint, never by index.

## Changelog

**0.1.2**

- **Fix: a dnode could silently fail to join, and the install timed out.** On
  the real cluster, two secondaries ran the image entrypoint's `CREATE DNODE`
  within the same second. One of them got exit 0 with **empty output**, logged
  "successfully joined cluster", and was never registered: its `taosd` then
  logged `Dnode does not exist` every second forever. The bootstrap job now,
  after `bootstrap.registerGraceSeconds` (default 60), runs `CREATE DNODE` for
  any expected dnode that is still missing — only if that dnode's pod exists
  (its headless DNS name resolves), so a Pending pod never becomes a phantom
  offline cluster member. Toggle: `bootstrap.registerMissingDnodes`.
- Verified: the manual `CREATE DNODE` recovered the stuck dnode within 4s on
  the real cluster; the new code, run there against a deliberately
  non-existent 4th dnode, issued only SELECTs and no `CREATE DNODE`; mock
  scenarios cover registration, the feature disabled, a missing pod, and the
  grace period.

**0.1.1**

- **Fix: taosAdapter crashed on start on cgroup v2 hosts**, so port 6041 never
  opened. Explorer failed with `Connection refused`, and the bootstrap job
  never got past waiting for the REST API. Cause: 0.1.0 set
  `TAOS_ADAPTER_MONITOR_INCGROUP=true`, which makes the adapter read the
  cgroup v1 file `/sys/fs/cgroup/cpu/cpu.cfs_period_us`
  (`MON FATAL new normal controller`). Removed; the image default works.
- **Fix: the bootstrap job died on a single refused connection.** Requests go
  through a load-balanced Service, so one can fail while a dnode's adapter is
  still starting or during a rolling restart. Transport errors are now retried;
  SQL errors still fail immediately.

**0.1.0** — initial release. Broken on cgroup v2 hosts; use 0.1.1.
